/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Edd;

/**
 *
 * @author emanu
 */
public class prbListaDLC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Listas lista1 = new Listas();
        Nodo r = null;
        Nodo n = new Nodo("h");
        Nodo n1 = new Nodo("o");
        Nodo n2 = new Nodo("l");
        Nodo n3 = new Nodo("a");
//    
//        Nodo b = new Nodo("p");
//        Nodo b1 = new Nodo("u");
//        Nodo e = new Nodo("s");
//        Nodo f = new Nodo("e");
//
//        String etq[] = new String[1];
//        etq[0] = "h";
//        r = Multilistas.insertar2(r, n, 0, etq, null);
//        etq[0] = "o";
//        r = Multilistas.insertar2(r, n1, 0, etq, null);
//        etq[0] = "l";
//        r = Multilistas.insertar2(r, c2, 0, etq,null);
//        etq[0] = "a";
//        r = Multilistas.insertar2(r, c3, 0, etq,null);

        //       elimina en el nivel 0 y son los paises
//
//        etq = new String[2];
//        etq[0] = "h";
//        etq[1] = "l";
//        r = Multilistas.insertar2(r, n2, 0, etq, null);
//        etq[1] = "a";
//        r = Multilistas.insertar2(r, n3, 0, etq, null);
//
//        etq = new String[1];
//        etq[0] = "h";
//        Nodo d[] = Multilistas.elimina(r, 0, etq);
//        r = d[0];
//        System.out.println("se elimino: " + d[1]);
//        
//        etq = new String[3];
//        etq[0] = "h";
//        etq[1] = "p";
//        etq[2] = "s";
//        r = Multilistas.insertar2(r, e, 0, etq,null);
//        etq = new String[4];
//        etq[0] = "h";
//        etq[1] = "p";
//        etq[2] = "s";
//        etq[3] = "e";
//        r = Multilistas.insertar2(r, f, 0, etq,null);
//
//
        System.out.println("");
    }

}
