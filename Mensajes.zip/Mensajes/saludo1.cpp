//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "saludo1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSaludoBox *SaludoBox;
//---------------------------------------------------------------------------
__fastcall TSaludoBox::TSaludoBox(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
